# hate-speech-detection-using-machine-learning
This python project analyses twitter data to identify hate speech and ctreates a machine learning model based on the dataset. The dataset is available on kaggle 
and you can find the link to the dataset in the description section of my youtube video which is attached below. The dataset contains labels indicating of the tweets 
are hate speech or not. Label 1 indicates hate speech and label 0 indicates non-hate speech tweets. 

To see the full video explanation, check out the following link:
https://youtu.be/TLbb1UbU0aQ

